from generator.var_generator import generate
