Usage:

1. Install ' python3.8 -m pip install <path>/generator-pkg-485652-Daniel-Kosc-0.0.1.tar.gz '
2. Run python ' python3 '
3. Import package >>> ' from generator import generate '
4. Print resut and return result >>> ' generate() ' 

Return/Print value:
>>> ANSIBLE_ARGS='--extra-vars "telnet_port=39312 username=Alaster password=jWMRpDaQ "' vagrant up server