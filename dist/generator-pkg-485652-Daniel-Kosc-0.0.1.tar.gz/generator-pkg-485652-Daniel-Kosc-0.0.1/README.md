<<<<<<< HEAD
Usage:

1. Install ' python3.8 -m pip install <path>/generator-pkg-485652-Daniel-Kosc-0.0.1.tar.gz '
2. Run python ' python3 '
3. Import package >>> ' from generator import generate '
4. Print resut and return result >>> ' generate() ' 

Return/Print value:
>>> ANSIBLE_ARGS='--extra-vars "telnet_port=39312 username=Alaster password=jWMRpDaQ "' vagrant up server
=======
To generate N players type :
`$ python3 generator.py N`
where N is number of players

You can change file names.txt and passwords.txt to generate from yours data.

After finish generating games you will see all names passwords and ports in file "players.yml" for each player.
>>>>>>> 8ddb826175856589811f5c4634b84ae1f323f5cf
