To generate N players type :
`$ python3 generator.py N`
where N is number of players

You can change file names.txt and passwords.txt to generate from yours data.

After finish generating games you will see all names passwords and ports in file "players.yml" for each player.